<?php

/**
 * Trigger this file on Plugin uninstall
 */

if ( ! defined( 'WP_UNINSTALL_PLUGIN' ) ) {
	die;
}


// Clear Database stored data



// Access the database via SQL