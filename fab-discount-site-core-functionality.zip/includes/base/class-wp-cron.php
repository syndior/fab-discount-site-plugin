<?php if ( ! defined( 'ABSPATH' ) ) exit;

class FD_WP_Cron
{
    public function __construct()
    {
        //code...
    }
}

new FD_WP_Cron();