<?php if ( ! defined( 'ABSPATH' ) ) exit;

class FD_Dokan_Controller
{
    public function __construct()
    {
     
    }

}

new FD_Dokan_Controller();